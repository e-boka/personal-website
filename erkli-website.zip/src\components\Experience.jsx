function Experience() {
  return (
    <section id="experience" className="section">
      <h2 className="section-title">Work Experience</h2>
      <div className="education-wrapper">
        <div className="education-card">
          <h3>Finance Assistant (Part-time)</h3>
          <p>Subashi Metal, Tirana, Albania</p>
          <span>Summer 2024</span>
          <ul>
            <li>Performed data reconciliation and verification to ensure accurate financial records.</li>
            <li>Organized and maintained financial datasets in support of the finance department.</li>
            <li>Gained practical exposure to finance operations and business workflows.</li>
          </ul>
        </div>
      </div>
    </section>
  )
}

export default Experience
