function SkillBar({ name, level }) {
  return (
    <div className="skill-card">
      <div className="skill-header">
        <span>{name}</span>
        <span>{level}%</span>
      </div>
      <div className="skill-bar-bg">
        <div className="skill-bar-fill" style={{ width: `${level}%` }}></div>
      </div>
    </div>
  )
}

export default SkillBar
