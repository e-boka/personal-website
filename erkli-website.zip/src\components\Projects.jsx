import ProjectCard from './ProjectCard'

function Projects({ projects }) {
  return (
    <section id="projects" className="section">
      <h2 className="section-title">University Projects</h2>
      <div className="projects-grid">
        {projects.map((project, index) => (
          <ProjectCard
            key={index}
            title={project.title}
            description={project.description}
            link={project.link}
          />
        ))}
      </div>
    </section>
  )
}

export default Projects
