function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 Erkli Boka. All rights reserved.</p>
    </footer>
  )
}

export default Footer
