function Education() {
  return (
    <section id="education" className="section">
      <h2 className="section-title">Education</h2>
      <div className="education-wrapper">
        <div className="education-card">
          <h3>Bachelor in Business Informatics</h3>
          <p>Epoka University, Tirana, Albania</p>
          <span>2024 – 2027 (Ongoing)</span>
          <p>
            Coursework includes database systems, programming, business analytics,
            systems design, and project-oriented problem solving.
          </p>
        </div>
      </div>
    </section>
  )
}

export default Education
