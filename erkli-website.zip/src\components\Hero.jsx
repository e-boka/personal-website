function Hero() {
  return (
    <section id="about" className="hero section">
      <div className="hero-content">
        <p className="intro">Hello, I am</p>
        <h1>Erkli Boka</h1>
        <h2>Business Informatics Student at Epoka University</h2>
        <p className="hero-description">
          Second-year Bachelor student at Epoka University with strong foundations
          in database design, Python scripting, Java application development,
          and finance operations support. Skilled in analytical problem solving
          and organized teamwork for academic and practical projects.
        </p>
        <div className="hero-buttons">
          <a href="#contact" className="primary-btn">Contact Me</a>
          <a href="#education" className="secondary-btn">View Education</a>
        </div>
      </div>
    </section>
  )
}

export default Hero
