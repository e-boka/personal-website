import { useState } from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Education from './components/Education'
import Experience from './components/Experience'
import Contact from './components/Contact'
import Footer from './components/Footer'

function App() {
  const [darkMode, setDarkMode] = useState(false)

  const skills = [
    { name: 'Database Management', level: 88 },
    { name: 'Python Programming', level: 80 },
    { name: 'Java Programming', level: 82 },
    { name: 'SQL / Schema Design', level: 85 },
    { name: 'Microsoft Office', level: 90 },
    { name: 'Business Analysis', level: 78 }
  ]

  const projects = [
    {
      title: 'Java Billing System',
      description:
        'University project built in Java with add-to-cart, remove-from-cart, and shopping list management. Implemented Admin and Seller roles with clean, modular application logic.',
      link: '#contact'
    },
    {
      title: 'Paint Company Database Analysis',
      description:
        'Designed a relational database schema for a paint manufacturing company and created SQL queries for reporting, filtering, and aggregation.',
      link: '#contact'
    }
  ]

  return (
    <div className={darkMode ? 'app dark' : 'app'}>
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
      <Hero />
      <Education />
      <Skills skills={skills} />
      <Projects projects={projects} />
      <Experience />
      <Contact />
      <Footer />
    </div>
  )
}

export default App
