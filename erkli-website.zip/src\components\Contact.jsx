function Contact() {
  return (
    <section id="contact" className="section">
      <h2 className="section-title">Contact & Details</h2>

      <div className="contact-layout">
        <div className="contact-info">
          <h3>Contact</h3>
          <p><strong>Email:</strong> erkliboka@gmail.com</p>
          <p><strong>Phone:</strong> +355 685374594</p>
          <p><strong>Location:</strong> Tirana, Albania</p>
          <p><strong>University:</strong> Epoka University</p>
        </div>

        <div className="contact-info">
          <h3>Languages</h3>
          <ul>
            <li>Albanian — Native</li>
            <li>English — Good level (reading, writing, communication)</li>
          </ul>

          <h3>Additional Skills</h3>
          <ul>
            <li>Analytical thinking and structured problem solving</li>
            <li>Strong teamwork, communication, and interpersonal skills</li>
            <li>Time management and self-organization</li>
            <li>Foundational knowledge of OOP and database design</li>
          </ul>
        </div>
      </div>
    </section>
  )
}

export default Contact
